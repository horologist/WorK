var InstallApp = {
    init: function (_params) {

        if(this.hasBeenClosed()) return;

        var self = this, device = this.getClientDevice(), app = {}, params = {
            ios: {
                link: '',
                text: '',
                button_text: '',
                system: false,
                app_id: 0,
                on_tablet: true
            },
            android: {
                link: '',
                text: '',
                button_text: '',
                on_tablet: true
            }
        };

        this._extend(params, _params);

        if(!device.mobile)
            return;

        switch(device.os) {
            case 'ios':
                if(params['ios'].link == '' && params['ios'].system == false)
                    return;
                break;

            case 'android':
                if(params['android'].link == '')
                    return;
                break;
        }

        if(!params[device.os].on_tablet && device.is_tablet)
            return;

        app = params[device.os];

        if(device.os == 'ios' && app.system) {
            var meta = document.createElement('meta');

            meta.name = "apple-itunes-app";
            meta.content = "app-id=" + params.ios.app_id;
            document.getElementsByTagName('head')[0].appendChild(meta);

            return;
        }

        var el = this.getTemplate(params.styles);

        //el.querySelector('.iapp-text').innerHTML = app['text'];
        //el.querySelector('.iapp-button').innerHTML = app['button_text'];

        this.current_link = app.link;

        document.body.appendChild(el);
    },
    hasBeenClosed: function() {
        return this.cookies.get('installapp_closed');
    },
    getTemplate: function(styles) {
        container_styles = {
            'position': 'fixed',
            'left': 0,
            'top': 10,
            'right': 0,
            'width': '100%',
            'min-height': '80px',
            'z-index': 1000,
//            'font-family':' tahoma, arial, verdana, sans-serif, Lucida Sans',
//            'font-size': '2em',
            'color': '#000',
            'background': 'linear-gradient(to top, #cdcdcd, #f4f4f4)',
            'border-top': '1px solid #aaaaab',
            'border-bottom': '1px solid #aaaaab'
        }, close_btn_styles = {
            'background': 'url(\'../images/close_bar.png\') no-repeat',
            'width': '19px',
            'height': '19px',
            'position': 'absolute',
            'margin': '-10px 0 0 10px',
            'cursor': 'pointer'
        }, red_head_styles = {
            'text-align': 'center',
            'margin-top': '5px',
            'font-size': '18px',
            'color': 'red'
        }, icon_styles = {
            'float': 'left',
            'margin': '3px 0 0 10px',
            'border': '1px solid #aaaaab',
            'border-radius': '3px'
        }, text_styles = {
            'float': 'left',
            'margin': '3px 0 0 5px',
            'padding': '0'
        }, btn_open_styles = {
            'margin': '10px 5px 0 0',
            'cursor': 'pointer',
            'background': 'linear-gradient(to top, #dcdcdc, #eeeeee)',
            'width': '75px',
            'height': '28px',
            'border': '1px solid #aaaaab',
            'border-radius': '3px',
            'float': 'right'
        };


        for(var i in styles) {
            switch(i) {
                case 'container':
                    this._extend(container_styles, styles['container']);
                    break;
                case 'close_btn':
                    this._extend(close_btn_styles, styles['close_btn']);
                    break;
                case 'red_head':
                    this._extend(red_head_styles, styles['red_head']);
                    break;
                case 'icon':
                    this._extend(icon_styles, styles['icon']);
                    break;
                case 'text_styles':
                    this._extend(text_styles, styles['text']);
                    break;
                case 'btn_open_styles':
                    this._extend(btn_open_styles, styles['btn_open']);
                    break;
            }
        }

        var template = '<div id="installapp" style="'+this.getStylesString(container_styles)+'"> \
                            <div class="iapp-text" style="'+this.getStylesString(close_btn_styles)+'" onclick="InstallApp.close()"></div> \
                            <div style="'+this.getStylesString(red_head_styles)+'" class="iapp-button" onclick="InstallApp.openApp();">Загрузите наше приложение!</div> \
                            <img src="/images/google-play-s.png" style="'+this.getStylesString(icon_styles)+'"> \
                            <div style="'+this.getStylesString(text_styles)+'"> \
                            РАТ - Своих не бросаем<br> \
                            FREE - On the Google Play \
                            </div> \
                            <div style="'+this.getStylesString(btn_open_styles)+'" onclick="InstallApp.openApp();"> \
                                <div style="margin: 4px 0 0 9px;">открыть</div> \
                            </div> \
                        </div>';

        var el = document.createElement('div');
        el.innerHTML = template;

        return el.firstChild;
    },
    current_link: '',
    openApp: function() {
        window.open(this.current_link);
    },
    close: function() {
        document.body.removeChild(document.getElementById('installapp'));

        this.cookies.set('installapp_closed', true, 1);
    },
    getScrollPos: function(el) {
        var x = 0, y = 0;
        if (el && el !== window) {
            x = el.scrollLeft;
            y = el.scrollTop;
        } else {
            if (typeof window.pageYOffset == 'number') {
                y = window.pageYOffset;
                x = window.pageXOffset;
            } else if (document.body && (document.body.scrollLeft || document.body.scrollTop)) {
                y = document.body.scrollTop;
                x = document.body.scrollLeft;
            } else if (document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
                y = document.documentElement.scrollTop;
                x = document.documentElement.scrollLeft;
            }
        }

        return {
            x: x,
            y: y
        };
    },
    getStylesString: function(styles) {
        var string, list = [];

        for(var i in styles) {
            list.push(i + ':' + styles[i]);
        }

        return list.join(';');
    },
    getDocumentSize: function () {
        var w = window.innerWidth || (document.documentElement && document.documentElement.clientWidth) || (document.body && document.body.clientWidth),
            h = window.innerHeight || (document.documentElement && document.documentElement.clientHeight) || (document.body && document.body.clientHeight);
        return {
            w: w,
            h: h
        };
    },
    getClientDevice: function() {
        var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/.test(navigator.appVersion);
        var osVersion = 0;
        var is_tablet = false;
        var os = false, clientStrings = [
            { s: 'android', r: /Android/},
            { s: 'ios', r: /(iPhone|iPad|iPod)/}
        ];

        for (var id in clientStrings) {
            var cs = clientStrings[id];
            if (cs.r.test(navigator.userAgent)) {
                os = cs.s;
                break;
            }
        }

        switch (os) {
            case 'android':
                osVersion = /Android ([\.\_\d]+)/.exec(navigator.userAgent)[1];
                is_tablet = (/mobile/i.test(navigator.userAgent.toLowerCase()));
                break;

            case 'ios':
                osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(navigator.appVersion);
                osVersion = osVersion[1] + '.' + osVersion[2] + '.' + (osVersion[3] | 0);
                is_tablet = (/ipad/i.test(navigator.userAgent.toLowerCase()));
                break;
        }

        return {
            mobile: mobile,
            os: os,
            osVersion: osVersion,
            is_tablet: is_tablet
        };
    },
    _extend: function(dest, source) {
        for(var i in source) {
            dest[i] = source[i];
        }
    },
    cookies: {
        get: function(name) {
            var cookieCrumbs = document.cookie.split(';');
            var nameToFind = name + '=';
            for (var i = 0; i < cookieCrumbs.length; i++) {
                var crumb = cookieCrumbs[i];
                while (crumb.charAt(0) == ' ') {
                    crumb = crumb.substring(1, crumb.length);
                }
                if (crumb.indexOf(nameToFind) == 0) {
                    return crumb.substring(nameToFind.length, crumb.length);
                }
            }
            return null;
        },
        set: function (name, value, days, domain) {
            var expires = '';
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = '; expires=' + date.toGMTString();
            }
            document.cookie = name + '=' + value + expires + '; path=/' + '; domain=' + window.location.host;
        }
    }
};