// @web-memory.ru 2014
$.fn.myClock = function(setup){
  var settings = $.extend( {
    'endDate'         : '0',
    'endTime'         : '0',
    'circle'          : '0',
    'cookie'          : '0',
    'cookieTime'      : '30',
    'dateOff'         : '1',
    'separDate'       : '',
    'separTime'       : '',
    'separBox'       : '<div class="counter-col"><div class="counter-separate">:</div></div>',
  }, setup);

  var elem = this;
  var timeMess='';
  if(settings.dateOff == 1) timeMess += '<div class="counter-col"><div class="counter-item days"></div><span class="counter-signature">Дней</span></div>'+settings.separBox;
  timeMess += '<div class="counter-col"><div class="counter-item hours"></div><span class="counter-signature">Часов</span></div>'+settings.separBox;
  timeMess += '<div class="counter-col"><div class="counter-item minutes"></div><span class="counter-signature">Минут</span></div>'+settings.separBox;
  timeMess += '<div class="counter-col"><div class="counter-item seconds"></div><span class="counter-signature">Секунд</span></div>';
  $(elem).html(timeMess);

  if($(this).attr("id")){
  	var elemCookie = $(this).attr("id");
  }else{
  	var elemCookie = $(elem).children().parent().attr('class');
  }

  if(settings.endDate != 0) startDate = new Date(settings.endDate);
  else startDate = new Date();
  var startTime = startDate;
  if(getCookie(elemCookie) && settings.cookie == 1) cookieTimeUTC =  getCookie(elemCookie);
  else cookieTimeUTC = Math.floor(startTime.getTime()+(settings.endTime*60*1000));

  var startTimeUTC = cookieTimeUTC;

  var zoneTime = startTime.getTimezoneOffset()*60*1000;

  if(settings.cookie == 1){
    if(!getCookie(elemCookie))setCookie(elemCookie, cookieTimeUTC, {expires: settings.cookieTime*60});
  }
  stopClock = new Array();
  if(!stopClock[elemCookie]){
    stopClock[elemCookie] = '0';
  }
  var intervalID = setInterval(
    function(){
      endTime = new Date();
      endTimeUTC = endTime.getTime();
      ostTime = new Date(startTimeUTC-endTime+zoneTime);
      d = Math.floor(ostTime.getDate()-1);
      h = Math.floor(ostTime.getHours());
      m = Math.floor(ostTime.getMinutes());
      s = Math.floor(ostTime.getSeconds());
      if(startTimeUTC <= endTimeUTC+1*1000){
        s = m = h = d = '00';
       	if(settings.circle == 1){
       	  startTimeUTC = Math.floor(endTimeUTC+(settings.endTime*60*1000));
       	}else{stopClock[elemCookie] = '1';clearInterval(intervalID);}
      }
      if(settings.dateOff == 1) $(elem).children('.counter-col').children('.days').html(addZero(d));
      $(elem).children('.counter-col').children('.hours').html(addZero(h));
      $(elem).children('.counter-col').children('.minutes').html(addZero(m));
      $(elem).children('.counter-col').children('.seconds').html(addZero(s));
    }
  ,10);

  function addZero(num){
    str = num+'';
    if(str.length < 2)num = '0'+num;
    return num;
  }

  function setCookie(name, value, options) {
    options = options || {};
    var expires = options.expires;

    if (typeof expires == "number" && expires) {
      var d = new Date();
      d.setTime(d.getTime() + expires*1000);
      expires = options.expires = d;
    }

    if (expires && expires.toUTCString) {
  	  options.expires = expires.toUTCString();
    }

    value = encodeURIComponent(value);
    var updatedCookie = name + "=" + value;

    for(var propName in options) {
      updatedCookie += "; " + propName;
      var propValue = options[propName];
      if (propValue !== true) {
        updatedCookie += "=" + propValue;
       }
    }

    document.cookie = updatedCookie;

  }

  function getCookie(name) {
    var matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  return stopClock;
};