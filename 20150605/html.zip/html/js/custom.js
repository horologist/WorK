/*	--------------------------	*/
/*	Анимация на сайте --------	*/
/*	--------------------------	*/
/*	Автор: Андрей Кривошеин --	*/
/*	E-mail: tvorex@yandex.ru -	*/

$(document).ready(function(){ 

	/*=====> Выделяем внешние ссылки <=====*/
	$('p > a[href^="http"]').attr({'target':'_blank'});
	$('.social-box > a[href^="http"]').attr({'target':'_blank'});
	
	/*=====> Плавный скроллинг к анкору ссылки <=====*/
	$('.smooth-scrolling').click(function () { /*обробочик события клика по ссылке с class-ом button-scroll  */
    var elementAncor = $(this).attr('href')/*чтение анкора ссылки*/
    var destination = $(elementAncor).offset().top; /*учитываем местоположение анкора на странице */
    jQuery('html:not(:animated),body:not(:animated)').animate({scrollTop: destination}, 1800); /* запускаем эфект анимирования (при клике)*/
return false;
	}); 
	
	/*=====> Анимация кнопки Телефонный звонок <=====*/
	var btnAnimate = setInterval(function(){
		$('.icon-phone').toggleClass('animated tada');
	}, 2000);
	  
	/*=====> Анимация кнопок Планируй — Накапливай — Получай <=====*/
	$('.item-flip').hover(function () {
		$('.item-flip').removeClass('flip');
		$(this).addClass('flip');
	});
	
	/*=====> Анимация кнопок соц. сетей в шапке сайта <=====*/
	$('.logo-text-social > a').hover(function () {
		$(this).toggleClass('animated rubberBand');
  });

  /*=====> Кнопка "раскрыть" меню в мобильной версии <=====*/
  $('#main-menu-btn-open').click(function () {
    $('html').css("overflow", "hidden");
  });
	
  /*=====> Кнопка "заскрыть" меню в мобильной версии <=====*/
  $('#main-menu-btn-close').click(function () {
    $('html').css("overflow", "visible")
  });
	
  /*=====> Переключить регистрация и авторизация <=====*/
  $('#auth-form-btn-login').click(function () {
    $('#carousel-authorization > div > .reg').removeClass('active');
    $('#carousel-authorization > div > .login').addClass('active');
  });
	
  /*=====> Прячим текст от поисковиков <=====*/
  $('#check-list-why >dt').addClass("hidden");
  $('.logo-text > span').addClass("hidden");
  $('.solution-block > h2').addClass("hidden");
  $('span.sr-only').addClass("hidden");
  $('.solution-figcaption').addClass("hidden");
  $('.payment-text').addClass("hidden");

  /*=====> Меню в футтере разделить на 3 колонки <=====*/
  $('#footer-menu > li:nth-child(n):nth-child(-n+3)').wrapAll("<div class='column'></div>");
  $('#footer-menu > li:nth-child(n):nth-child(-n+4)').wrapAll("<div class='column'></div>");
  $('#footer-menu > li:nth-child(n):nth-child(-n+5)').wrapAll("<div class='column'></div>");
  
});


/*=====> Анимация счетчиков <=====*/
jQuery(document).ready(function( $ ) {
    $('.counter-wrap').counterUp({
        delay: 10,
        time: 900
    });
});
  

/*=====> Плавное появление панели <=====*/
jQuery(function () {
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 0) {
			jQuery('.page-header').addClass("floating");
    } else {
          jQuery('.page-header').removeClass("floating")
    ;}
	});
});


/*=====> Плавный переход на вверх страницы <=====*/
jQuery(function () {
	jQuery('.copyright_box').click(function () {
		jQuery('body,html').stop(false, false).animate({
			scrollTop: 0
		}, 800);
		return false;
	});
});

/*=====> Таймер обратного отчёта <=====*/
$(document).ready(function() {

 $('#counter-main').myClock({
 	endTime:6*23*60,
  dateOff:1,
 	cookie:1,
 	cookieTime:7*24*60,
 });

 $("#stop").click( function() {
    if(stopClock['clock1'] == 1){
      $('.error').html('<span style="color:#00AC00;">Таймер остановлен</span>');
    }else{
      $('.error').html('<span style="color:#E60000;">Таймер еще работает</span>');
    }
    return false;
  });

});


/*=====> Слайдер в отзывах <=====*/
  jQuery(function( $ ) {
    $('.tabpanel-box').tosrus({
      slides		: {
        visible	: 2,
      },
    });
  });

