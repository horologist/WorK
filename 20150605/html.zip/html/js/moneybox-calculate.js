$(document).ready(function(){

	var moneyRange = $('#moneyRange'), // Какую сумму хотите накопить.
        timeRange = $('#timeRange'),  // Сколько времени вы готовы копить.
        donateCount = $('#donateCount'), // Сколько взносов нужно сделать.
        priceCount = $('#priceCount'), // Размер взноса.
        stockCount = $('#stock'), // Размер накопления.
        outputCount = $('#outputCount'), // Размер выплаты.
        percentBonusCount = $('#percentBonusCount'), // Бонус в процентах.
        priceBonusCount = $('#priceBonusCount'), // Бонус в деньгах.
        overalCount = $('#overalCount'), // кнопка для выбора способа расчета.
        countRool = false, // Способ расчета ежемесячных взносов, с учетом скидки или без. Если с учетом скидки (true), то "Вы накопите" и "Выплата составит" будут равны.
        garantMultiplyFactor = 1.5, //коэффициент умножения денег.
        firstCalcWeek = 21; // Первая неделя, для которой расчитывается динамический коэффициент умножения.

	moneyRange.on('change', calculate);
	timeRange.on('change', calculate);

	calculate();

	function calculate () {
		var curMoneyRange = moneyRange.val(), // Выбранное значение размера накоплений
			curTimeRange = timeRange.val(), // Выбранное значение кол-ва недель
			curPayment = roundCrop(Payment(curMoneyRange, curTimeRange), 2), // Размер еженедельного взноса без скидки
			currentMultiplyFactor = K(curTimeRange, firstCalcWeek), // Текущее коэффициента умножения
			dinamicMultiplyFactor = roundCrop(currentMultiplyFactor, 2, 'floor'), // Текущий, динамический коэффициент умножения, расчитываемый для конкретного кол-ва недель
			dinamicDiscountFactor = roundCrop(D(currentMultiplyFactor), 4, 'special'), // Текущий, динамический коэффициент скидки, расчитываемый для конкретного кол-ва недель
			dinamicBonus = roundCrop(Bonus(curPayment, curTimeRange, dinamicDiscountFactor), 2); // Рамер бонуса в абсолютном показателе
			finalPayment = roundCrop((+curMoneyRange * currentMultiplyFactor), 2, 'floor'); // Сумма полной выплаты с учетом процентов

		donateCount.text(curTimeRange);
		priceCount.text(curPayment);
		stockCount.text(curMoneyRange);
		outputCount.text(finalPayment);

		percentBonusCount.text(roundCrop((dinamicDiscountFactor * 100), 2)); // Размер бонуса в процентах
		priceBonusCount.text(dinamicBonus);

	};

	function roundCrop (number, count, type ){ // (Число, Цифр после запятой, Тип округления)
		var count = count || 2,
			type = type || 'round',
			countPow = Math.pow(10, count);
		
		switch (type) {
			case 'floor': number = Math.floor(number*countPow)/countPow;
				break;
			case 'ceil': number = Math.ceil(number*countPow)/countPow;
				break;
			case 'round': number = Math.round(number*countPow)/countPow;
				break;
			case 'special': number = Math.round( Math.round( number*countPow*0.2 )/0.2 )/countPow;
				break;
			default: number = Math.round(number*countPow)/countPow;
				break;
		};

		var tempString = number + '',
			arr = tempString.split('.');

			arr[1] = arr[1]||'';	
		return parseFloat(arr[0]+'.'+arr[1].substring(0,count+1));
	};

	//Формула коэффициента умножения
	function K (week, first){ //(номер недели, первая неделя с которой считается коэффициент)
		if (week < first) {
			return garantMultiplyFactor;
		} else {
			return 1 + week/26;
		};
	};

	//Формула коэффициента скидки
	function D (k){
		return 1 - garantMultiplyFactor/k;
	};

	//Формула расчета размера взноса
	function Payment (summ, week, discaunt){ // (общая сумма, кол-во недель, скидка на платеж)
		var discaunt = discaunt || 0,
			result = summ / (week * garantMultiplyFactor);

		if (discaunt) {
			return result * discaunt;
		} else {
			return result;
		}
	};

	//Формула расчета размера бонуса
	function Bonus(payment, week, discaunt){
		return payment * week * discaunt ;
	}
});