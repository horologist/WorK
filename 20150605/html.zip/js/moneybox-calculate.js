$(document).ready(function(){

	var moneyRange = $('#moneyRange'), // Какую сумму хотите накопить.
        timeRange = $('#timeRange'),  // Сколько времени вы готовы копить.
        donateCount = $('#donateCount'), // Сколько взносов нужно сделать.
        paymentCount = $('#priceCount'), // Размер взноса.
        stockCount = $('#stock'), // Размер накопления.
        outputCount = $('#outputCount'), // Размер выплаты.
        percentBonusCount = $('#percentBonusCount'), // Бонус в процентах.
        priceBonusCount = $('#priceBonusCount'), // Бонус в деньгах.
        overalCount = $('#overalCount'), // кнопка для выбора способа расчета.
        countRool = false, // Способ расчета ежемесячных взносов, с учетом скидки или без. Если с учетом скидки (true), то "Вы накопите" и "Выплата составит" будут равны.
        garantMultiplyFactor = 1.5, //коэффициент умножения денег.
        firstCalcWeek = 21, // Первая неделя, для которой расчитывается динамический коэффициент умножения.
        minPayment = 10; // Размер минимальной ставки до "firstCalcWeek" недели, тоесть до первой калькулируемой недели.

	moneyRange.on('change', calculate);
	timeRange.on('change', calculate);

	calculate();

	function calculate () {
		var finalPayment = moneyRange.val(), // Выбранное значение размера накоплений
			curTimeRange = timeRange.val(), // Выбранное значение кол-ва недель
			dinamicMultiplyFactor = K(curTimeRange, firstCalcWeek), // Текущий, динамический коэффициент умножения, расчитываемый для конкретного кол-ва недель
			dinamicDiscountFactor = D(dinamicMultiplyFactor), // Текущий, динамический коэффициент скидки, расчитываемый для конкретного кол-ва недель
			virtualPayment = Payment(finalPayment, curTimeRange, dinamicMultiplyFactor, dinamicDiscountFactor), //Виртуальное значение платежа без скидок используется как переводной коэффициент дял согласования формул
			curPayment = virtualPayment-virtualPayment*dinamicDiscountFactor; // Размер еженедельного взноса с учетом скидки

		// Событие "если"" до первой расчетной недели с расчитываемым коэффициентом
		if ((curTimeRange < firstCalcWeek) && (curPayment > minPayment)) {
			curPayment = minPayment; 
			finalPayment = curTimeRange*curPayment*dinamicMultiplyFactor;
			virtualPayment = Payment(finalPayment, curTimeRange, dinamicMultiplyFactor, dinamicDiscountFactor), //Виртуальное значение платежа без скидок используется как переводной коэффициент дял согласования формул
			curPayment = virtualPayment-virtualPayment*dinamicDiscountFactor; // Размер еженедельного взноса с учетом скидки
			moneyRange.val(finalPayment).trigger('input');
		}

		var	youCharge = curPayment*curTimeRange, //Вы накопите на взносах за все время
			dinamicBonus = roundCrop((youCharge*(dinamicMultiplyFactor-1)), 2, 'special'), // Рамер бонуса в абсолютном показателе
			dinamicBonusPercent = roundCrop((dinamicMultiplyFactor - 1)*100, 2);//Размер бонуса в процентах

		donateCount.text(curTimeRange);
		paymentCount.text(roundCrop(curPayment, 2));
		stockCount.text(roundCrop(youCharge, 2));
		outputCount.text(finalPayment);

		percentBonusCount.text(dinamicBonusPercent);
		priceBonusCount.text(dinamicBonus);

	};

	function roundCrop (number, count, type ){ // (Число, Цифр после запятой, Тип округления)
		var count = count || 2,
			type = type || 'round',
			countPow = Math.pow(10, count);
		
		switch (type) {
			case 'floor': number = Math.floor(number*countPow)/countPow;
				break;
			case 'ceil': number = Math.ceil(number*countPow)/countPow;
				break;
			case 'round': number = Math.round(number*countPow)/countPow;
				break;
			case 'special': number = Math.round( Math.round( number*countPow*0.2 )/0.2 )/countPow;
				break;
			default: number = Math.round(number*countPow)/countPow;
				break;
		};

		var tempString = number + '',
			arr = tempString.split('.');

			arr[1] = arr[1]||'';	
		return parseFloat(arr[0]+'.'+arr[1].substring(0,count+1));
	};

	//Формула коэффициента умножения
	function K (week, first){ //(номер недели, первая неделя с которой считается коэффициент)
		if (week < first) {
			return garantMultiplyFactor;
		} else {
			return 1 + week/26;
		};
	};

	//Формула коэффициента скидки
	function D (k){
		return 1 - garantMultiplyFactor/k;
	};

	//Формула расчета размера пеерводного взноса
	function Payment(summ, week, k, d){ // (общая сумма, кол-во недель, коэффициент K, коэффициент D)
		return summ/(week*k*(1-d));
	};
});